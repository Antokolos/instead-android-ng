local std = stead
local instead = std.ref '@instead'

instead.savepath = instead_savepath
std.savepath = instead_savepath
instead.gamepath = instead_gamepath
instead.exepath = instead_exepath
