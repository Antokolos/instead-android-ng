sprite = stead.ref '@sprite'
pixels = stead.ref '@pixels'
